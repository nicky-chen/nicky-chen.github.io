 

---
title: 阅读书单 
author: "nicky_chin"
date: 2017-03-17T11:18:15+08:00
share: true
slug: book_list
draft: false
aliases: [/post/external/book_list.html]
--- 

* 1 **并发编程相关**
    1. 《Java多线程编程核心技术》
    2. 《Java并发编程从入门到精通》
    3. 《Java并发编程的艺术》
    4. 《Java 并发编程实战》
    5. 《深入理解 Java 内存模型》
    6. 《实战Java高并发程序设计》
    
    
* 2 **MYSQL相关**
    1. 《Mysql-5.7官方文档》
    2. 《高性能MySQL 第3版》
    3. 《数据库索引设计与优化》
    4. 《数据库查询优化器的艺术》
    5. 《MySQL排错指南》
    6. 《MySQL技术内幕：InnoDB存储引擎1~2卷》
    
* 3 **算法相关**
    1. 《Java数据结构和算法》
    2. 《IT名企算法与数据结构题目最优解》
    3. 《从PAXOS到ZOOKEEPER分布式一致性原理与实践》
    
    
* 4 **分布式和架构**
    1. 《分布式Java应用基础与实践》
    2. 《大型网站系统与Java中间件实践》
    3. 《分布式服务架构：原理、设计与实战》
    4. 《可伸缩服务架构:框架与中间件》
    5. 《构建高性能web站点》
    6. 《大型网站技术架构：核心原理与案例分析》
    7. 《亿级流量网站架构核心技术》
    
* 5 **缓存相关**
    1. 《redis设计与实现(第二版)》
    2. 《深入分布式缓存》
    3. 《REDIS开发与运维》
    
* 6 **JVM虚拟机**
    1. 《Java虚拟机（第二版）》
    2. 《自己动手写Java虚拟机》
    
* 7 **Java Web**
    1. 《深入分析Java Web技术内幕》
    2. 《Spring源码深度解析》
    3. 《SPRING技术内幕》
    
* 8 **其他**
    1. 《HTTP权威指南》
    2. 《How Tomcat Works》
    3. 《Java性能优化权威指南》
    4. 《Netty权威指南 第2版》
    5. 《TCP-IP详解(卷一、二、三)》