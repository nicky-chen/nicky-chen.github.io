---
title: 在线工具 
author: "nicky_chin"
date: 2017-02-19T11:18:15+08:00
share: true
slug: tools
draft: false
aliases: [/post/external/tools.html]
---

[cron定时任务表达式](http://cron.qqe2.com/)

[编码格式转换](http://tool.chinaz.com/tools/unicode.aspx)

[JVM参数调优](http://xxfox.perfma.com/)

[apache镜像](https://www.apache.org/dyn/closer.cgi)

[java源码搜索](http://grepcode.com/)

[JSON在线解析](https://www.json.cn/)

[谷歌市场国外软件下载](http://apps.evozi.com/)

[PYPI](https://pypi.org/)

[Python-Package](https://www.lfd.uci.edu/~gohlke/pythonlibs/)

[正则代码生成](http://tool.chinaz.com/regex)

[RGB颜色参考](http://tool.oschina.net/commons?type=3)

[在线格式转换](https://www.hipdf.com/)

[sitemap自动生成](https://www.xml-sitemaps.com/)

[markdown转公众号文章](https://github.com/dyc87112/online-markdown)

[加密解密工具](http://tool.chacuo.net/cryptdes)